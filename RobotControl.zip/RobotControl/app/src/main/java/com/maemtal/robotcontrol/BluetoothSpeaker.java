package com.maemtal.robotcontrol;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.media.AudioDeviceInfo;
import android.media.AudioFormat;
import android.media.AudioManager;
import android.media.AudioRecord;
import android.media.AudioTrack;
import android.media.MediaRecorder;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.speech.RecognizerIntent;
import android.speech.tts.TextToSpeech;
import android.support.annotation.Nullable;
import android.support.v4.app.ActivityCompat;
import android.util.Log;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Locale;
import java.util.UUID;

public class BluetoothSpeaker extends Activity {
    private static final String TAG = "bluetooth2";


    TextView txtArduino;
    RelativeLayout rlayout;
    final int RECIEVE_MESSAGE = 1;        // Status  for Handler
    private BluetoothAdapter btAdapter = null;
    private BluetoothSocket btSocket = null;
    private StringBuilder sb = new StringBuilder();
    private static int flag = 0;

    private BluetoothSpeaker.ConnectedThread mConnectedThread;

    // SPP UUID service
    private static final UUID MY_UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");

    // MAC-address of Bluetooth module (you must edit this line)
    private static String address = "00:21:09:00:26:2B";
    TextToSpeech turkceSeslendir;
    /** Called when the activity is first created. */
    LinearLayout main;
    TextView text, textSolution;

    @Override
    protected void onStart() {
        super.onStart();
        sesKayitIzni();
    }
    private void sesKayitIzni() {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, 77);
            }
        }
    }
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Locale locale = new Locale("tr", "TR");
        setContentView(R.layout.calculator);
        main = (LinearLayout) findViewById(R.id.main);
        text = (TextView) findViewById(R.id.txtInput);
        textSolution = (TextView) findViewById(R.id.txtSolution);
        address = getIntent().getExtras().getString("btAdress");

        turkceSeslendir = new TextToSpeech(getApplicationContext(), new TextToSpeech.OnInitListener() {
            @Override
            public void onInit(int status) {
                if (status != TextToSpeech.ERROR) {

                    turkceSeslendir.setLanguage(locale);
                }
            }
        });
        btAdapter = BluetoothAdapter.getDefaultAdapter();       // get Bluetooth adapter
        checkBTState();
        setAudioDevice();

    }

    AudioManager audioManager;

    private void setAudioDevice() {
        audioManager = (AudioManager) getSystemService(Context.AUDIO_SERVICE);

        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.M) {
            AudioDeviceInfo[] devices = audioManager.getDevices(AudioManager.GET_DEVICES_OUTPUTS);
            for (AudioDeviceInfo device : devices) {
                if (device.getType() == AudioDeviceInfo.TYPE_BLUETOOTH_A2DP) {// BLE_Speaker ile değiştirilebilir
                    //audioManager.set
                }
            }
        }
    }

    String[] rTag = {"1", "2", "3", "4", "5", "6", "7", "8", "9"};
    String[] oTag = {"+", "-", "*", "/"};

    int x, y;

    void rakamaAcKapa(boolean ac, int sayi) {
        for (String s : rTag) {
            main.findViewWithTag(s).setEnabled(ac);
        }
    }

    void operatorAcKapa(boolean ac) {
        for (String s : oTag) {
            main.findViewWithTag(s).setEnabled(ac);
        }
    }


    public void temizle(View v) {
        goster = "";
        last = "";
        text.setText("");
        textSolution.setText("");
    }

    String goster = "";
    String last = "";

    public void gonder(View v) {
        v.setEnabled(false);
        if ((last == "" || last == "+" || last == "-" || last == "*" || last == "/") && (v.getTag().toString().equals("=") || v.getTag().toString().equals("-") || v.getTag().toString().equals("+") || v.getTag().toString().equals("/") || v.getTag().toString().equals("*"))) {
            return;
        }
        if (!v.getTag().toString().equals("=")) {
            goster += v.getTag().toString();
        }

        last = v.getTag().toString();
        text.setText(goster);
        switch (v.getTag().toString()) {

            case "=":

                //goster=""+sonuc;

                Matematik mat = new Matematik(goster);
                int result = (int) mat.evaluate();
                textSolution.setText(result + "");
                goster = result + "";

                text.setText(goster);

                mConnectedThread.write(result + ".");
                turkceSeslendir.speak((int) result + "", TextToSpeech.QUEUE_FLUSH, null);
                break;
            default:
                break;

        }
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                v.setEnabled(true);
            }
        }, 500);

    }

    protected static final int RESULT_SPEECH = 111;

    AudioRecord audioRecord;
    AudioTrack audioTrack;
    public void ses(View v) {
        int audioSource = MediaRecorder.AudioSource.MIC;
        int audioFormat = AudioFormat.ENCODING_PCM_16BIT;
        int sampleRate = 44100;
        int channel = AudioFormat.CHANNEL_IN_MONO;
        int bufferSize = AudioRecord.getMinBufferSize(sampleRate, channel, audioFormat);

// Create an AudioRecord instance to capture audio from the microphone
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            // TODO: Consider calling
            //    ActivityCompat#requestPermissions
            // here to request the missing permissions, and then overriding
            //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
            //                                          int[] grantResults)
            // to handle the case where the user grants the permission. See the documentation
            // for ActivityCompat#requestPermissions for more details.
            return;
        }
        audioRecord = new AudioRecord(audioSource, sampleRate,
                channel, audioFormat, bufferSize);

// Create an AudioTrack instance to play audio on the Bluetooth speaker
       audioTrack = new AudioTrack(AudioManager.STREAM_MUSIC,
                sampleRate, AudioFormat.CHANNEL_OUT_MONO, audioFormat, bufferSize,
                AudioTrack.MODE_STREAM);

// Start recording and playing
        audioRecord.startRecording();
        audioTrack.play();

// Create a byte array to store the audio data
        byte[] data = new byte[bufferSize];

// Loop until the user stops the app
        while (true) {
            // Read audio data from the microphone
            int read = audioRecord.read(data, 0, bufferSize);

            // Check if the read was successful
            if (read != AudioRecord.ERROR_INVALID_OPERATION) {
                // Write audio data to the Bluetooth speaker
                audioTrack.write(data, 0, read);
            }
        }




    }
    public void kapat(){
        if(audioRecord!=null&&audioTrack!=null){
            audioRecord.stop();
            audioTrack.stop();
            audioRecord.release();
            audioTrack.release();
        }

    }
    boolean yaz=false;
    int deger=0;
    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        switch (requestCode) {
            case RESULT_SPEECH: {
                if (resultCode == RESULT_OK && null != data) {

                    ArrayList<String> textH = data
                            .getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);

                    textSolution.setText(textH.get(0));
                    //IslemIfade i=new IslemIfade(text.get(0));
                    //txtText.setText(i.hesapla()+"");
                    SoundCalculator sc=new SoundCalculator(textH.get(0));
                    double sonuc= sc.hesapla();
                    goster=(int)sonuc+"";
                    last=(int)sonuc+"";
                    text.setText(goster+"");
                    textSolution.setText(sonuc+"");

                    turkceSeslendir.speak((int)sonuc+"", TextToSpeech.QUEUE_FLUSH, null);
                    // mConnectedThread.write(goster+".");
                    deger=(int)sonuc;
                    yaz=true;


                }
                break;
            }

        }
    }

    private BluetoothSocket createBluetoothSocket(BluetoothDevice device) throws IOException {
        if (Build.VERSION.SDK_INT >= 10) {
            try {
                final Method m = device.getClass().getMethod("createInsecureRfcommSocketToServiceRecord", new Class[]{UUID.class});
                return (BluetoothSocket) m.invoke(device, MY_UUID);
            } catch (Exception e) {
                Log.e(TAG, "Could not create Insecure RFComm Connection", e);
            }
        }

        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                requestPermissions(new String[]{Manifest.permission.BLUETOOTH_CONNECT}, 1);
            }
        }
        return device.createRfcommSocketToServiceRecord(MY_UUID);
    }

    @Override
    public void onResume() {
        super.onResume();

        Log.d(TAG, "...onResume - try connect...");

        // Set up a pointer to the remote node using it's address.
        BluetoothDevice device = btAdapter.getRemoteDevice(address);

        // Two things are needed to make a connection:
        //   A MAC address, which we got above.
        //   A Service ID or UUID.  In this case we are using the
        //     UUID for SPP.

        try {
            btSocket = createBluetoothSocket(device);
        } catch (IOException e) {
            errorExit("Fatal Error", "In onResume() and socket create failed: " + e.getMessage() + ".");
        }

        // Discovery is resource intensive.  Make sure it isn't going on
        // when you attempt to connect and pass your message.


        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_SCAN) != PackageManager.PERMISSION_GRANTED) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                requestPermissions(new String[]{Manifest.permission.BLUETOOTH_SCAN,Manifest.permission.BLUETOOTH_CONNECT}, 1);
            }
        }

        btAdapter.cancelDiscovery();

        // Establish the connection.  This will block until it connects.
        Log.d(TAG, "...Connecting...");
        try {
            if (ActivityCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    requestPermissions(new String[]{Manifest.permission.BLUETOOTH_CONNECT}, 2);
                }
            }
            btSocket.connect();
            Log.d(TAG, "....Connection ok...");
        } catch (IOException e) {
            try {
                btSocket.close();
            } catch (IOException e2) {
                errorExit("Fatal Error", "In onResume() and unable to close socket during connection failure" + e2.getMessage() + ".");
            }
        }

        // Create a data stream so we can talk to server.
        Log.d(TAG, "...Create Socket...");

        mConnectedThread = new BluetoothSpeaker.ConnectedThread(btSocket);
        mConnectedThread.start();
        if(yaz){
            mConnectedThread.write(deger+".");
            yaz=false;
        }
    }

    @Override
    public void onPause() {
        super.onPause();

        Log.d(TAG, "...In onPause()...");

        try {
            btSocket.close();
        } catch (IOException e2) {
            errorExit("Fatal Error", "In onPause() and failed to close socket." + e2.getMessage() + ".");
        }
    }

    private void checkBTState() {
        // Check for Bluetooth support and then check to make sure it is turned on
        // Emulator doesn't support Bluetooth and will return null
        if (btAdapter == null) {
            errorExit("Fatal Error", "Bluetooth not support");
        } else {
            if (btAdapter.isEnabled()) {
                Log.d(TAG, "...Bluetooth ON...");
            } else {
                //Prompt user to turn on Bluetooth
                Intent enableBtIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
                if (ActivityCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                        requestPermissions(new String[]{Manifest.permission.BLUETOOTH_CONNECT},1);
                    }
                }
                startActivityForResult(enableBtIntent, 1);
            }
        }
    }

    private void errorExit(String title, String message){
        Toast.makeText(getBaseContext(), title + " - " + message, Toast.LENGTH_LONG).show();
        finish();
    }

    private class ConnectedThread extends Thread {
        private final InputStream mmInStream;
        private final OutputStream mmOutStream;

        public ConnectedThread(BluetoothSocket socket) {
            InputStream tmpIn = null;
            OutputStream tmpOut = null;

            // Get the input and output streams, using temp objects because
            // member streams are final
            try {
                tmpIn = socket.getInputStream();
                tmpOut = socket.getOutputStream();
            } catch (IOException e) { }

            mmInStream = tmpIn;
            mmOutStream = tmpOut;
        }



        /* Call this from the main activity to send data to the remote device */
        public void write(String message) {
            Log.d(TAG, "...Veri gönderiliyor : " + message + "...");
            byte[] msgBuffer = message.getBytes();
            try {
                mmOutStream.write(msgBuffer);
            } catch (IOException e) {
                Log.d(TAG, "...Veri gönderme de hata oldu : " + e.getMessage() + "...");
            }
        }
    }


}