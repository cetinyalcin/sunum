package com.maemtal.robotcontrol;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class SoundCalculator {
    private String ifade;
    private double sonuc;
    public SoundCalculator(String _ifade){
         ifade=_ifade.toLowerCase();

    }
    public double hesapla(){
        if(ifade.contains("daha")||ifade.contains("topla")||ifade.contains("ekle")||ifade.contains("+")){
        return topla();
        }else if(ifade.contains("çıkar")||ifade.contains("fark")||ifade.contains("eksi")||ifade.contains("-")){
         return cikar();
        }else if(ifade.contains("kere")||ifade.contains("çarp")||(ifade.contains("tane")&&!ifade.contains("kaç tane"))||ifade.contains("x")){
          return carp();
        } if(ifade.contains("böl")||ifade.contains("kaç tane")||ifade.contains("kaç adet")||ifade.contains("/")){
         return bol();
        }else{
            return Integer.MIN_VALUE;
        }

    }
    private double topla(){
        double deger=0;
        Pattern pattern= Pattern.compile("\\d+");
        Matcher match=pattern.matcher(ifade);
        while (match.find()){
            deger+=Integer.parseInt(match.group());
        }
        return deger;
    }
    private  double cikar(){
        double deger=0;
        Pattern pattern= Pattern.compile("\\d+");
        Matcher match=pattern.matcher(ifade);
        int i=0;
        while (match.find()){
            int sayi=Integer.parseInt(match.group());
            if(i==0){
                deger=sayi;
            }else{
            deger-=sayi;
            }
            i++;
        }
        return deger;
    }
    private double carp(){
        double deger=1;
        Pattern pattern= Pattern.compile("\\d+");
        Matcher match=pattern.matcher(ifade);
        while (match.find()){
            deger*=Integer.parseInt(match.group());
        }
        return deger;
    }
    private double bol(){
        double deger=0;
        Pattern pattern= Pattern.compile("\\d+");
        Matcher match=pattern.matcher(ifade);
        int i=0;
        while (match.find()){
            int sayi=Integer.parseInt(match.group());
            if(i==0){
                deger=sayi;
            }else{
                deger/=sayi;
            }
            i++;
        }
        return deger;
    }
}
