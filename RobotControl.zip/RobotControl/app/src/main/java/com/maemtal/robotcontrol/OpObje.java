package com.maemtal.dream;

public interface OpObje {
    public int eval(int a, int b);
}
