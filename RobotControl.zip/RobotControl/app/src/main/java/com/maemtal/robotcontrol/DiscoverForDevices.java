package com.maemtal.dream;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.location.LocationManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Debug;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.ActivityCompat;
import android.util.Log;
import android.view.View;
import android.widget.Toast;


public class DiscoverForDevices extends Activity {
    BluetoothAdapter btAdapter;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        btAdapter = BluetoothAdapter.getDefaultAdapter();

        // Register for broadcasts when a device is discovered.
        setContentView(R.layout.discover);


    }


    public void arabaAra(View view) {

        bluetoothAra();

    }

    private void baglanmaIzni() {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                requestPermissions(new String[]{Manifest.permission.BLUETOOTH_CONNECT}, 1);
            }
        } else {
            taramaIzni();
        }
    }


    private boolean bi() {
        return ActivityCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED;
    }

    private boolean ti() {
        return ActivityCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_SCAN) == PackageManager.PERMISSION_GRANTED;
    }

    private boolean ki() {
        return ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED;
    }

    private boolean recordAudio() {
        return ActivityCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED;
    }
    private boolean btAcikMi() {
        return btAdapter.isEnabled();
    }

    @SuppressLint("MissingPermission")
    private void btAc() {
        Intent enableBtIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
        startActivityForResult(enableBtIntent, 4);
    }

    private boolean konumAcikMi() {
        return ((LocationManager) getSystemService(Context.LOCATION_SERVICE)).isProviderEnabled(LocationManager.GPS_PROVIDER);
    }

    private void konumAc() {
        startActivityForResult(new Intent(android.provider.Settings.ACTION_LOCATION_SOURCE_SETTINGS), 5);
    }

    @SuppressLint("MissingPermission")
    private void bluetoothAra() {
        IntentFilter filter = new IntentFilter(BluetoothDevice.ACTION_FOUND);
        registerReceiver(receiver, filter);
        if (bi()) {
            if (ti()) {
                if (ki()) {
                    if (btAcikMi()) {
                        if (konumAcikMi()) {
                            boolean b = btAdapter.startDiscovery();
                            if (!b) {
                                mesajGoster("Tarama başlamadı");
                            }
                        } else {
                            konumAc();
                        }
                    } else {
                        btAc();
                    }

                } else {
                    konumIzni();
                }
            } else {
                taramaIzni();
            }
        } else {
            baglanmaIzni();
        }


    }

    // Create a BroadcastReceiver for ACTION_FOUND
    private final BroadcastReceiver receiver = new BroadcastReceiver() {
        public void onReceive(Context context, Intent intent) {
            String action = intent.getAction();

            if (BluetoothDevice.ACTION_FOUND.equals(action)) {
                // Discovery has found a device. Get the BluetoothDevice
                // object and its info from the Intent.
                BluetoothDevice device = intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE);
                if (ActivityCompat.checkSelfPermission(DiscoverForDevices.this, Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                        requestPermissions(new String[]{Manifest.permission.BLUETOOTH_CONNECT}, 1);
                    }

                } else {
                    String deviceName = device.getName();
                    String deviceHardwareAddress = device.getAddress(); // MAC address
                    consoldaGoster(deviceName + " " + deviceHardwareAddress);
                    if (deviceName != null) {
                        Log.d("Cihaz Adı",deviceName);
                        if (deviceName.contains("HC-06")) {

                            mesajGoster("Cihaz Bulundu");
                            btAdapter.cancelDiscovery();
                            sayfaAc(deviceHardwareAddress);

                        }else if(deviceName.contains("BT-SPEAKER")){
                            btAdapter.cancelDiscovery();
                            sayfaAcHoparlor(deviceHardwareAddress);
                        }
                    }
                    consoldaGoster("Ad:" + deviceName + " -Adress:" + deviceHardwareAddress);
                }

            }

        }
    };

    private void sayfaAc(String mesaj) {
        Intent in = new Intent(DiscoverForDevices.this, Calculator.class);
        in.putExtra("btAdress", mesaj);
        startActivity(in);
    }
    private void sayfaAcHoparlor(String mesaj) {
        Intent in = new Intent(DiscoverForDevices.this, BluetoothSpeaker.class);
        in.putExtra("btAdress", mesaj);
        startActivity(in);
    }
    private void mesajGoster(String msj) {
        Toast.makeText(this, msj, Toast.LENGTH_SHORT).show();
    }

    private void consoldaGoster(String mesaj) {
        Log.i("Bilgi", mesaj);
    }

    private void pairDevice(String deviceName, String deviceAdress) {

    }

    private void taramaIzni() {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_SCAN) != PackageManager.PERMISSION_GRANTED) {

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                requestPermissions(new String[]{Manifest.permission.BLUETOOTH_SCAN}, 2);
            }
        }
    }

    private void konumIzni() {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, 3);
            }
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        switch (requestCode) {
            case 1:
                if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    bluetoothAra();

                } else {
                    mesajGoster("Bluetooth cihazına bağlanma izni vermeden uygulamayı kullanamazsınız.");
                    bluetoothAra();
                }
                break;
            case 2:
                if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    bluetoothAra();
                } else {
                    mesajGoster("Bluetooth cihazına Tarama izni vermeden uygulamayı kullanamazsınız.");
                    bluetoothAra();
                }
                break;
            case 3:
                if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    bluetoothAra();
                } else {
                    mesajGoster("Konuma erişme izni vermeden uygulamayı kullanamazsınız.");
                    bluetoothAra();
                }
                break;
            default:
                break;
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 4) {
            if (resultCode == RESULT_OK) {
                if (((LocationManager) getSystemService(Context.LOCATION_SERVICE)).isProviderEnabled(LocationManager.GPS_PROVIDER)) {
                    bluetoothAra();
                } else {
                    startActivityForResult(new Intent(android.provider.Settings.ACTION_LOCATION_SOURCE_SETTINGS), 5);
                }
            } else {
                mesajGoster("Bluetooth'u açmadan Taramayı Başlatamazsınız.");
            }
        } else if (requestCode == 5) {
            if (resultCode == RESULT_OK) {
                bluetoothAra();
            } else {
                mesajGoster("Konum servisini açmadan Taramayı Başlatamazsınız.");
                bluetoothAra();
            }
        }
    }

    @Override
    protected void onStart() {
        super.onStart();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        unregisterReceiver(receiver);
    }
}
