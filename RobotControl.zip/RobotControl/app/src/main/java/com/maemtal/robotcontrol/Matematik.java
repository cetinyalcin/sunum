package com.maemtal.robotcontrol;

import java.util.Stack;

public class Matematik {
// A java class that can evaluate a mathematical expression given as a string
// It does not use any java library, just pure java code
// It assumes the expression is valid and follows the order of operations
// It supports the operators +, -, *, / and parentheses ( and )


        // A constructor that takes a string expression as an argument
        // and stores it as a field
        private String expression;

        public Matematik(String expression) {
            this.expression = expression;
        }

        // A method that returns the precedence of an operator
        // Higher precedence means higher priority
        // Returns -1 if the character is not an operator
        private int precedence(char op) {
            switch (op) {
                case '+':
                case '-':
                    return 1;
                case '*':
                case '/':
                    return 2;
                default:
                    return -1;
            }
        }

        // A method that performs the arithmetic operation on two operands
        // Returns the result of the operation
        // Throws an exception if the operator is invalid or the divisor is zero
        private double apply(char op, double a, double b) {
            switch (op) {
                case '+':
                    return a + b;
                case '-':
                    return a - b;
                case '*':
                    return a * b;
                case '/':
                    if (b == 0) {
                        throw new ArithmeticException("Division by zero");
                    }
                    return a / b;
                default:
                    throw new IllegalArgumentException("Invalid operator: " + op);
            }
        }

        // A method that evaluates the expression and returns the calculated result
        public double evaluate() {
            // Initialize two stacks to store the operands and operators
            Stack<Double> operands = new Stack<>();
            Stack<Character> operators = new Stack<>();

            // Loop through each character in the expression
            for (int i = 0; i < expression.length(); i++) {
                char c = expression.charAt(i);

                // If the character is a digit or a decimal point, parse the number and push it to the operands stack
                if (Character.isDigit(c) || c == '.') {
                    // Find the end of the number
                    int j = i;
                    while (j < expression.length() && (Character.isDigit(expression.charAt(j)) || expression.charAt(j) == '.')) {
                        j++;
                    }
                    // Convert the substring to a double and push it to the operands stack
                    double num = Double.parseDouble(expression.substring(i, j));
                    operands.push(num);
                    // Update the index to skip the number
                    i = j - 1;
                }

                // If the character is an opening parenthesis, push it to the operators stack
                else if (c == '(') {
                    operators.push(c);
                }

                // If the character is a closing parenthesis, pop and apply the operators until an opening parenthesis is found
                else if (c == ')') {
                    while (!operators.isEmpty() && operators.peek() != '(') {
                        // Pop the top two operands and the top operator
                        double b = operands.pop();
                        double a = operands.pop();
                        char op = operators.pop();
                        // Apply the operator on the operands and push the result to the operands stack
                        double result = apply(op, a, b);
                        operands.push(result);
                    }
                    // Pop the opening parenthesis from the operators stack
                    if (!operators.isEmpty()) {
                        operators.pop();
                    }
                }

                // If the character is an operator, pop and apply the operators with higher or equal precedence
                // Then push the current operator to the operators stack
                else if (precedence(c) > 0) {
                    while (!operators.isEmpty() && precedence(operators.peek()) >= precedence(c)) {
                        // Pop the top two operands and the top operator
                        double b = operands.pop();
                        double a = operands.pop();
                        char op = operators.pop();
                        // Apply the operator on the operands and push the result to the operands stack
                        double result = apply(op, a, b);
                        operands.push(result);
                    }
                    // Push the current operator to the operators stack
                    operators.push(c);
                }
            }

            // After the loop, pop and apply the remaining operators until the operators stack is empty
            while (!operators.isEmpty()) {
                // Pop the top two operands and the top operator
                double b = operands.pop();
                double a = operands.pop();
                char op = operators.pop();
                // Apply the operator on the operands and push the result to the operands stack
                double result = apply(op, a, b);
                operands.push(result);
            }

            // The final result is the only element left in the operands stack
            return operands.pop();
        }


}
