package com.maemtal.dream;

public class IslemIfade {
    // sonuc özelliği tanımı
    private double sonuc;

    // yapıcı metod tanımı
    public IslemIfade(String ifade) {
        // sonuc özelliğini 0 olarak başlat
        sonuc = 0;
        // ifadeyi boşluklara göre böl ve diziye ata
        String[] bolumler = ifade.split(" ");
        // eğer bölümler dizisi 3 elemanlı değilse
        if (bolumler.length != 3) {
            // sonucu NaN yap
            sonuc = Double.NaN;
        } else {
            // bölümler dizisinin ilk elemanını a değişkenine ata
            double a = Double.parseDouble(bolumler[0]);
            // bölümler dizisinin ikinci elemanını islem değişkenine ata
            String islem = bolumler[1];
            // bölümler dizisinin üçüncü elemanını b değişkenine ata
            double b = Double.parseDouble(bolumler[2]);
            // islem değişkenine göre sonucu hesapla
            switch (islem) {
                case "daha":
                case "+":
                    // toplama işlemi
                    sonuc = a + b;
                    break;
                case "eksi":
                case "-":
                    // çıkarma işlemi
                    sonuc = a - b;
                    break;
                case "kere":
                case "çarpı":
                case "*":
                    // çarpma işlemi
                    sonuc = a * b;
                    break;
                case "bölü":
                case "/":
                    // bölme işlemi
                    sonuc = a / b;
                    break;
                default:
                    // geçersiz işlem
                    sonuc = Double.NaN;
                    break;
            }
        }
    }

    // hesapla metodunun tanımı
    public double hesapla() {
        // sonuc özelliğini ekrana yazdır
        return sonuc;
    }
}
